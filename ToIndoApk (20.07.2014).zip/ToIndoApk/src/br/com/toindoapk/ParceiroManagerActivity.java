package br.com.toindoapk;


import br.com.toindoapk.fragments.FragmentHistoricoPromo;
import br.com.toindoapk.fragments.FragmentInfoParceiro;
import br.com.toindoapk.fragments.FragmentNovaPromo;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Vector;

import com.facebook.Session;

import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.support.v4.app.Fragment;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class ParceiroManagerActivity extends FragmentActivity {
	
	public static final int IMAGEM_INTERNA = 1;
	public static final String CATEGORIA = "CATEGORIA";	
	private Parceiro parceiro;	
	private byte[] arrayOfImage;
	
	
	private android.app.ActionBar actionbar;
	private PagerAdapter mPagerAdapter;
	private ViewPager mViewPager;
	private List<Fragment> fragments; 
		
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewpager_layout);
		initialisePaging();
		
		
		getObjects();
		setObjects();
		TabsActionBar();
			
		
		if (savedInstanceState != null){
			int indiceTab = savedInstanceState.getInt("indiceTab");
			getActionBar().setSelectedNavigationItem(indiceTab);
		}else{
			getActionBar().setSelectedNavigationItem(0);
		}
	}
	
	private void initialisePaging() {
		// TODO Auto-generated method stub
		fragments = new Vector<Fragment>();
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentInfoParceiro.class.getName()));
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentHistoricoPromo.class.getName()));
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentNovaPromo.class.getName()));
		mPagerAdapter = new PagerAdapter(this.getSupportFragmentManager(), fragments);
		
		mViewPager = (ViewPager) findViewById(R.id.viewpager);
		mViewPager.setAdapter(mPagerAdapter);
		
		mViewPager
		.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
			@Override
			public void onPageSelected(int position) {
				actionbar.setSelectedNavigationItem(position);
			}
		});

	}
	
	public void getObjects(){		
		actionbar = getActionBar();
	}
	
	public void setObjects(){
		actionbar.setIcon(R.drawable.logo);
		actionbar.setTitle("");
		actionbar.setDisplayHomeAsUpEnabled(true);
		}
	
	public void TabsActionBar(){
		actionbar.setNavigationMode(android.app.ActionBar.NAVIGATION_MODE_TABS);
		
		Tab info = actionbar.newTab();
		info.setText("Info");
		info.setTabListener(new NavegacaoTabs(new FragmentInfoParceiro()));
		actionbar.addTab(info, false);
		
		Tab historico = actionbar.newTab();
		historico.setText("Historico");
		historico.setTabListener(new NavegacaoTabs(new FragmentHistoricoPromo()));
		actionbar.addTab(historico, false);
		
		Tab novaPromo = actionbar.newTab();
		novaPromo.setText("Nova");
		novaPromo.setTabListener(new NavegacaoTabs(new FragmentNovaPromo()));
		actionbar.addTab(novaPromo, false);
	}
	
	private class NavegacaoTabs implements ActionBar.TabListener{
		private Fragment frag;
		
		public NavegacaoTabs(Fragment frag){
			this.frag = frag;
		}
		
		@Override
		public void onTabSelected(Tab tab, android.app.FragmentTransaction ft) {
			FragmentTransaction fts = getSupportFragmentManager().beginTransaction();
			fts.replace(R.id.fragmentContainer, frag);
			fts.commit();
			
			mViewPager.setCurrentItem(tab.getPosition());
		}

		@Override
		public void onTabUnselected(Tab tab, android.app.FragmentTransaction ft) {
			FragmentTransaction fts = getSupportFragmentManager().beginTransaction();
			fts.remove(frag);
			fts.commit();
			
		}

		@Override
		public void onTabReselected(Tab tab, android.app.FragmentTransaction ft) {
			Log.i("Script", "onTabReselected");
			
		}
		
	}
	
	@Override
	public void onSaveInstanceState(Bundle outState){
		super.onSaveInstanceState(outState);
		outState.putInt("indiceTab", getActionBar().getSelectedNavigationIndex());
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.parceiro_manager, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()){
		case android.R.id.home:
			Log.i("script","ok");
			break;
		case R.id.exit:
			Log.i("script","Sair");
			if (Session.getActiveSession() !=null){
				Session.getActiveSession().closeAndClearTokenInformation();
				}
			Intent intent = new Intent(getApplicationContext(), MainActivity.class);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
			break;		
	}
		return super.onOptionsItemSelected(item);
	}
	
	// ////////////////////////////////////////////////////////////////////////////////////////////////

			public void pegarImgButtonClick(View view) {
				Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
				intent.setType("image/*");
				startActivityForResult(intent, IMAGEM_INTERNA);
			}

			@Override
			public void onActivityResult(int requestCode, int resultCode,
					Intent intent) {
				if (requestCode == IMAGEM_INTERNA) {
					if (resultCode == RESULT_OK) {

						Uri imagemSelecionada = intent.getData();

						String[] colunas = { MediaStore.Images.Media.DATA };

						Cursor cursor = getContentResolver().query(imagemSelecionada,colunas, null, null, null);
						cursor.moveToFirst();

						int indexColuna = cursor.getColumnIndex(colunas[0]);

						String pathImg = cursor.getString(indexColuna);
						
						Log.i(CATEGORIA, "String do pathImg=" + pathImg);

						cursor.close();

						Bitmap bitmap = BitmapFactory.decodeFile(pathImg);

						// Convertendo o Bitmap em uma array de bytes
						convertBitmapAsByte(bitmap, Bitmap.CompressFormat.JPEG);
						arrayOfImage = convertBitmapAsByte(bitmap,Bitmap.CompressFormat.JPEG);
						
						Log.i(CATEGORIA, arrayOfImage.toString());

						ImageView iv = (ImageView) findViewById(R.id.imageViewPromocao);
						iv.setImageBitmap(bitmap);

					}
				}
			} 

			public static final byte[] convertBitmapAsByte(Bitmap bitmap,
					CompressFormat compressFormat) {

				ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
				bitmap.compress(compressFormat, 0, outputStream);
				return outputStream.toByteArray();
			}

			public static final Bitmap convertByteAsBitmap(byte[] imgBytes) {

				return BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.length);
			}
			
			

			public void getInfoLogin() {
				Intent intent = getIntent();
				parceiro = new Parceiro();

				if (intent != null) {
					Bundle params = intent.getExtras();

					if (params != null) {

						parceiro.setIdFacebook(params.getString("user_id"));

						parceiro.setNomeParceiro(params.getString("user_name"));

						parceiro.setEmailParceiro(params.getString("user_email"));

					}

				}
			}

			// //Enviar a promocao

			public void enviarButtonClick(View view) {
				
				
				final EditText editDataValidade = (EditText) findViewById(R.id.editDataValidade);

				final EditText editPrecoAnterior = (EditText) findViewById(R.id.editPrecoAnterior);

				final EditText editPrecoPromocional = (EditText) findViewById(R.id.editPrecoPromocional);

				final EditText editDescricao = (EditText) findViewById(R.id.editDescricao);

				if (editDataValidade.getText().toString().length() <= 0) {
					Log.i("CATEGORIA", editDataValidade.getText().toString());
					//editDataValidade.setError("Insira uma Data!");
					editDataValidade.requestFocus();
					
				}else if (editPrecoAnterior.getText().toString().length() <= 0) {
					editPrecoAnterior.setError("Insira o Preco Anterior!");
					editPrecoAnterior.requestFocus();

				}

				else if (editPrecoPromocional.getText().toString().length() <= 0) {
					editPrecoPromocional.setError("Insira o Preco Promocional!");
					editPrecoPromocional.requestFocus();

				}

				else if (editDescricao.getText().toString().length() <= 0) {
					editDescricao.setError("Escreva uma descricao!");
					editDescricao.requestFocus();
				}

				else {
					try {

						final SQLiteDatabase db = openOrCreateDatabase("toindo.db",	Context.MODE_PRIVATE, null);
						final Cursor cursor_parceiro = db.rawQuery("SELECT * FROM parceiro WHERE idFacebook = ?", new String[] {parceiro.getIdFacebook() });
													
						ContentValues ctv = new ContentValues();
						ctv.put("estabelecimento", cursor_parceiro.getString(0));
						ctv.put("data_validade", editDataValidade.getText().toString());
						ctv.put("preco_anterior", editPrecoAnterior.getText().toString());
						ctv.put("preco_promocional", editPrecoPromocional.getText().toString());
						ctv.put("descricao", editDescricao.getText().toString());
						ctv.put("imagem", arrayOfImage);
						
						if (db.insert("promocao", "_id", ctv) > 0) {
							Toast.makeText(getBaseContext(), "Sucesso ao enviar",
									Toast.LENGTH_SHORT).show();
							Intent intent = new Intent(getApplicationContext(),
									ParceiroManagerActivity.class);
							startActivity(intent);
							finish();
							overridePendingTransition(android.R.anim.slide_in_left,
									android.R.anim.slide_out_right);

						} else {
							Toast.makeText(getBaseContext(), "Erro ao enviar",
									Toast.LENGTH_SHORT).show();

						}
						db.close();
					} catch (Exception ex) {
						Toast.makeText(getBaseContext(), ex.getMessage(),
								Toast.LENGTH_SHORT).show();
					}
				}

			}
	
	
	

}
