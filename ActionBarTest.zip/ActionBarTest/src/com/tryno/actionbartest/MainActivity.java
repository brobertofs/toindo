package com.tryno.actionbartest;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.facebook.*;
import com.facebook.android.Facebook;
import com.facebook.model.*;


public class MainActivity extends ActionBarActivity {
	
	private ActionBar actionbar;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//Funcao do botao via api
		
		/*ImageButton fb_login_button = (ImageButton) findViewById(R.id.fb_login_button);
		fb_login_button.setOnClickListener(new View.OnClickListener() {
			@Override
		    public void onClick(View v) {
				loginToFacebook(v);
				
			}
		}); */
		
		getObjects();
		setObjects();
		hideActionBar();

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}		
	}
	
	public void loginToFacebook(View v){
				
		// start Facebook Login
		  Session.openActiveSession(this, true, new Session.StatusCallback() {			  

		    // callback when session changes state
		    @Override
		    public void call(Session session, SessionState state, Exception exception) {
		    	
		    	if (session.isOpened()) {
		    		// make request to the /me API
		    		Request.newMeRequest(session, new Request.GraphUserCallback() {

		    		  // callback after Graph API response with user object
		    		  @Override
		    		  public void onCompleted(GraphUser user, Response response) {
		    			  if (user != null) {
		    				  
		    				  TextView welcome = (TextView) findViewById(R.id.welcome);
		    				  welcome.setText("Hello " + user.getName() + "!");
		    				 
		    				  //Intent it = new Intent (MainActivity.this, ActionBarTestActivity.class);	
		    				  //startActivity(it);		    				  
		    				}
		    		  }
		    		}).executeAsync();
		    	}

		    }
		  });
	}
			
	public void setObjects(){
		actionbar.setIcon(R.drawable.icon);
		actionbar.setTitle(R.string.MyActionBar);
		actionbar.setDisplayHomeAsUpEnabled(true);
		}	
	public void getObjects(){
		actionbar = getSupportActionBar();
	}
	public void hideActionBar(){
		actionbar.hide();		
	}	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}

}
