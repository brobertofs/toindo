/** Automatically generated file. DO NOT MODIFY */
package com.tryno.actionbartest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}