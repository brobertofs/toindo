package br.com.toindoapk;


import br.com.toindoapk.fragments.FragmentHistoricoPromo;
import br.com.toindoapk.fragments.FragmentInfoParceiro;
import br.com.toindoapk.fragments.FragmentNovaPromo;

import java.util.List;
import java.util.Vector;
import com.facebook.Session;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;


public class ParceiroManagerActivity extends FragmentActivity {
	private android.app.ActionBar actionbar;
	private PagerAdapter mPagerAdapter;
	private ViewPager mViewPager;
	private List<Fragment> fragments; 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewpager_layout);
		initialisePaging();
		
		
		getObjects();
		setObjects();
		TabsActionBar();
		
		if (savedInstanceState != null){
			int indiceTab = savedInstanceState.getInt("indiceTab");
			getActionBar().setSelectedNavigationItem(indiceTab);
		}else{
			getActionBar().setSelectedNavigationItem(0);
		}
	}
	
	private void initialisePaging() {
		// TODO Auto-generated method stub
		fragments = new Vector<Fragment>();
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentInfoParceiro.class.getName()));
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentHistoricoPromo.class.getName()));
		fragments.add(Fragment.instantiate(getBaseContext(), FragmentNovaPromo.class.getName()));
		mPagerAdapter = new PagerAdapter(this.getSupportFragmentManager(), fragments);
		
		mViewPager = (ViewPager) findViewById(R.id.viewpager);
		mViewPager.setAdapter(mPagerAdapter);
		
		mViewPager
		.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
			@Override
			public void onPageSelected(int position) {
				actionbar.setSelectedNavigationItem(position);
			}
		});

	}
	
	public void getObjects(){		
		actionbar = getActionBar();
	}
	
	public void setObjects(){
		actionbar.setIcon(R.drawable.logo);
		actionbar.setTitle("");
		actionbar.setDisplayHomeAsUpEnabled(true);
		}
	
	public void TabsActionBar(){
		actionbar.setNavigationMode(android.app.ActionBar.NAVIGATION_MODE_TABS);
		
		Tab info = actionbar.newTab();
		info.setText("Info");
		info.setTabListener(new NavegacaoTabs(new FragmentInfoParceiro()));
		actionbar.addTab(info, false);
		
		Tab historico = actionbar.newTab();
		historico.setText("Historico");
		historico.setTabListener(new NavegacaoTabs(new FragmentHistoricoPromo()));
		actionbar.addTab(historico, false);
		
		Tab novaPromo = actionbar.newTab();
		novaPromo.setText("Nova");
		novaPromo.setTabListener(new NavegacaoTabs(new FragmentNovaPromo()));
		actionbar.addTab(novaPromo, false);
	}
	
	private class NavegacaoTabs implements ActionBar.TabListener{
		private Fragment frag;
		
		public NavegacaoTabs(Fragment frag){
			this.frag = frag;
		}
		
		@Override
		public void onTabSelected(Tab tab, android.app.FragmentTransaction ft) {
			FragmentTransaction fts = getSupportFragmentManager().beginTransaction();
			fts.replace(R.id.fragmentContainer, frag);
			fts.commit();
			
			mViewPager.setCurrentItem(tab.getPosition());
		}

		@Override
		public void onTabUnselected(Tab tab, android.app.FragmentTransaction ft) {
			FragmentTransaction fts = getSupportFragmentManager().beginTransaction();
			fts.remove(frag);
			fts.commit();
			
		}

		@Override
		public void onTabReselected(Tab tab, android.app.FragmentTransaction ft) {
			Log.i("Script", "onTabReselected");
			
		}
		
	}
	
	@Override
	public void onSaveInstanceState(Bundle outState){
		super.onSaveInstanceState(outState);
		outState.putInt("indiceTab", getActionBar().getSelectedNavigationIndex());
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.parceiro_manager, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()){
		case android.R.id.home:
			Log.i("script","ok");
			break;
		case R.id.exit:
			Log.i("script","Sair");
			if (Session.getActiveSession() !=null){
				Session.getActiveSession().closeAndClearTokenInformation();
				}
			Intent intent = new Intent(getApplicationContext(), MainActivity.class);
			startActivity(intent);
			finish();
			overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
			break;		
	}
		return super.onOptionsItemSelected(item);
	}

}
