package br.com.toindoapk;



import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SimpleCursorAdapter;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

public class OfertasActivity extends ActionBarActivity {

	protected static final String CATEGORIA = "MyApp_OfertasActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ofertas);

		if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}

	}

	// /// LogCat
	private String getClassName() {
		String s = getClass().getName();
		return s.substring(s.lastIndexOf("."));
	}

	@Override
	public void onResume() {
	    super.onResume();
	    Log.i(CATEGORIA,getClassName() + ".onRestart() chamado.");	
	    SQLiteDatabase db = openOrCreateDatabase("toindo.db", Context.MODE_PRIVATE, null);
	    Cursor cursor = db.rawQuery ("SELECT promocao._id AS _id, nome_estabelecimento, data_validade, preco_anterior, preco_promocional, descricao FROM parceiro INNER JOIN promocao ON parceiro._id=promocao.estabelecimento UNION SELECT promocao._id AS _id, nome_estabelecimento, data_validade, preco_anterior, preco_promocional, descricao FROM parceiro LEFT OUTER JOIN promocao ON parceiro._id=promocao.estabelecimento ORDER BY data_validade DESC",null);
	    	
		String[] from = {"nome_estabelecimento", "data_validade", "preco_anterior", "preco_promocional","descricao"};
		int[] to = { R.id.textViewNomeEstabelecimento, R.id.textViewDataValidade, R.id.textViewPrecoAnterior, R.id.textViewPrecoPromocional, R.id.textViewDescricao};
		
		
		SimpleCursorAdapter ad = new SimpleCursorAdapter(this,R.layout.listar_info_ofertas,cursor, from, to);
		
		
		ListView listViewPromocoes = (ListView) findViewById(R.id.list_view_promocoes);
		listViewPromocoes.setAdapter(ad);
		
		listViewPromocoes.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> adapter, View view,
					int position, long id) {
				
				SQLiteCursor c = (SQLiteCursor) adapter.getAdapter().getItem(position);

				Intent it = new Intent(getBaseContext(), InformacoesGeraisActivity.class);
				it.putExtra("id", c.getInt(0));
				startActivity(it);
			}
		});
				
		
		db.close(); 		
	
	}

	@Override
	public void onPause() {
		super.onPause();
		Log.i(CATEGORIA, getClassName() + ".onPause() chamado.");
	}

	@Override
	public void onStop() {
		super.onStop();
		Log.i(CATEGORIA, getClassName() + ".onStop() chamado.");

	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		Log.i(CATEGORIA, getClassName() + ".onDestroy() chamado.");

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ofertas, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_ofertas,
					container, false);
			return rootView;
		}
	}

}
